import { CarState, InputState, CarSpec, TireSmoke, SkidMark, Spark, Building, TrafficCone } from './types';
import { checkBuildingCollision } from './city';

const CAR_WIDTH = 20;
const CAR_HEIGHT = 40;
const DRAG = 0.995;

export function initCarState(): CarState {
  return {
    x: 60,
    y: 60,
    angle: 0,
    speed: 0,
    angularVelocity: 0,
    drifting: false,
    driftAngle: 0,
    steerAngle: 0,
    throttle: 0,
    brake: 0,
    handbrake: false,
  };
}

export function updateCar(
  car: CarState,
  input: InputState,
  spec: CarSpec,
  _dt: number,
  buildings: Building[],
  cones: TrafficCone[]
): {
  car: CarState;
  smoke: TireSmoke[];
  skids: SkidMark[];
  sparks: Spark[];
  isDrifting: boolean;
  driftAmount: number;
  hitCone: boolean;
} {
  const newCar = { ...car };
  const smoke: TireSmoke[] = [];
  const skids: SkidMark[] = [];
  const sparks: Spark[] = [];
  let hitCone = false;

  // Throttle & Brake
  if (input.up) {
    newCar.throttle = Math.min(newCar.throttle + 0.05, 1);
  } else {
    newCar.throttle = Math.max(newCar.throttle - 0.03, 0);
  }

  if (input.down) {
    newCar.brake = Math.min(newCar.brake + 0.08, 1);
  } else {
    newCar.brake = Math.max(newCar.brake - 0.05, 0);
  }

  newCar.handbrake = input.handbrake;

  // Acceleration
  const accel = newCar.throttle * spec.acceleration;
  newCar.speed += accel;

  // Braking
  if (newCar.brake > 0) {
    if (newCar.speed > 0) {
      newCar.speed -= newCar.brake * 0.15;
    } else {
      newCar.speed -= newCar.brake * spec.acceleration * 0.5;
    }
  }

  // Max speed
  newCar.speed = Math.max(Math.min(newCar.speed, spec.maxSpeed), -spec.maxSpeed * 0.3);

  // Friction
  newCar.speed *= DRAG;

  // Steering
  const steerSpeed = 0.045 / (1 + Math.abs(newCar.speed) * 0.05);
  if (input.left) {
    newCar.steerAngle = Math.max(newCar.steerAngle - steerSpeed, -0.6);
  } else if (input.right) {
    newCar.steerAngle = Math.min(newCar.steerAngle + steerSpeed, 0.6);
  } else {
    newCar.steerAngle *= 0.7;
  }

  // Calculate drift
  const speedFactor = Math.abs(newCar.speed) / spec.maxSpeed;
  const steerFactor = Math.abs(newCar.steerAngle);
  const driftThreshold = newCar.handbrake ? 0.1 : 0.3;

  let isDrifting = false;
  let driftAmount = 0;

  if (speedFactor > driftThreshold && steerFactor > 0.15) {
    isDrifting = true;
    driftAmount = speedFactor * steerFactor;
  }

  if (newCar.handbrake) {
    isDrifting = speedFactor > 0.05;
    driftAmount = Math.max(driftAmount, speedFactor * 0.8);
    newCar.speed *= (0.97 + spec.grip * 0.02);
  }

  // Angular velocity
  const turnRate = newCar.steerAngle * Math.abs(newCar.speed) * 0.04;

  if (isDrifting) {
    const driftSteer = newCar.handbrake ? 0.85 : spec.driftFactor;
    newCar.angularVelocity += (turnRate - newCar.angularVelocity) * (1 - driftSteer) * 2;
    newCar.angularVelocity *= 0.95;

    // Extra rotation during drift
    const extraRotation = newCar.steerAngle * speedFactor * 0.03 * (newCar.handbrake ? 2.5 : 1.0);
    newCar.angularVelocity += extraRotation;
  } else {
    newCar.angularVelocity = turnRate;
  }

  newCar.angle += newCar.angularVelocity;
  newCar.drifting = isDrifting;

  // Movement
  const moveAngle = isDrifting
    ? newCar.angle - newCar.angularVelocity * spec.driftFactor * 3
    : newCar.angle;

  const vx = Math.sin(moveAngle) * newCar.speed;
  const vy = -Math.cos(moveAngle) * newCar.speed;

  newCar.x += vx;
  newCar.y += vy;

  // Building collisions
  const collision = checkBuildingCollision(
    newCar.x, newCar.y, CAR_WIDTH, CAR_HEIGHT, newCar.angle, buildings
  );

  if (collision.collided) {
    newCar.x += collision.pushX;
    newCar.y += collision.pushY;
    newCar.speed *= 0.5;

    // Create sparks on collision
    for (let i = 0; i < 5; i++) {
      sparks.push({
        x: newCar.x + collision.pushX * 3,
        y: newCar.y + collision.pushY * 3,
        vx: (Math.random() - 0.5) * 8,
        vy: (Math.random() - 0.5) * 8,
        life: 20 + Math.random() * 20,
        alpha: 1,
        color: Math.random() > 0.5 ? '#FFD700' : '#FF6B00',
      });
    }
  }

  // Cone collisions
  for (const cone of cones) {
    if (cone.hit) continue;
    const dx = newCar.x - cone.x;
    const dy = newCar.y - cone.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 20) {
      cone.hit = true;
      hitCone = true;
    }
  }

  // Generate tire smoke and skid marks during drift
  if (isDrifting && Math.abs(newCar.speed) > 1) {
    const cos = Math.cos(newCar.angle);
    const sin = Math.sin(newCar.angle);

    // Rear tire positions
    const rearLeft = {
      x: newCar.x - sin * (CAR_HEIGHT * 0.35) - cos * (CAR_WIDTH * 0.4),
      y: newCar.y + cos * (CAR_HEIGHT * 0.35) - sin * (CAR_WIDTH * 0.4),
    };
    const rearRight = {
      x: newCar.x - sin * (CAR_HEIGHT * 0.35) + cos * (CAR_WIDTH * 0.4),
      y: newCar.y + cos * (CAR_HEIGHT * 0.35) + sin * (CAR_WIDTH * 0.4),
    };

    // Smoke particles
    for (let i = 0; i < 2; i++) {
      const pos = i === 0 ? rearLeft : rearRight;
      smoke.push({
        x: pos.x + (Math.random() - 0.5) * 5,
        y: pos.y + (Math.random() - 0.5) * 5,
        alpha: 0.4 + driftAmount * 0.3,
        size: 8 + driftAmount * 15,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        life: 40 + Math.random() * 30,
      });
    }

    // Skid marks
    skids.push({
      x: rearLeft.x,
      y: rearLeft.y,
      angle: newCar.angle,
      alpha: Math.min(0.6, driftAmount),
      width: 3,
    });
    skids.push({
      x: rearRight.x,
      y: rearRight.y,
      angle: newCar.angle,
      alpha: Math.min(0.6, driftAmount),
      width: 3,
    });
  }

  return { car: newCar, smoke, skids, sparks, isDrifting, driftAmount, hitCone };
}

export { CAR_WIDTH, CAR_HEIGHT };

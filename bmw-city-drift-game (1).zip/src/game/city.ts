import { Building, TrafficCone } from './types';

const CITY_SIZE = 4000;
const ROAD_WIDTH = 120;
const BLOCK_SIZE = 400;

export function generateCity(): { buildings: Building[]; cones: TrafficCone[] } {
  const buildings: Building[] = [];
  const cones: TrafficCone[] = [];

  const buildingColors = [
    '#2C3E50', '#34495E', '#1B2631', '#283747', '#1C2833',
    '#212F3C', '#1A5276', '#154360', '#0E3A5D', '#1F3A52',
    '#2E4053', '#273746', '#1B2A3D', '#223344', '#1A2A3A',
  ];

  const roofColors = [
    '#3498DB', '#2980B9', '#1ABC9C', '#E74C3C', '#9B59B6',
    '#F39C12', '#E67E22', '#27AE60', '#2ECC71', '#16A085',
  ];

  // Grid layout
  for (let bx = -CITY_SIZE / 2; bx < CITY_SIZE / 2; bx += BLOCK_SIZE) {
    for (let by = -CITY_SIZE / 2; by < CITY_SIZE / 2; by += BLOCK_SIZE) {
      const isRoadX = Math.abs((bx + CITY_SIZE / 2) % BLOCK_SIZE) < ROAD_WIDTH;
      const isRoadY = Math.abs((by + CITY_SIZE / 2) % BLOCK_SIZE) < ROAD_WIDTH;

      if (!isRoadX && !isRoadY) {
        // Building block
        const margin = 15;
        const maxBuildingSize = BLOCK_SIZE - ROAD_WIDTH - margin * 2;

        // Create sub-buildings within each block
        const subdivisions = Math.floor(Math.random() * 3) + 1;

        if (subdivisions === 1) {
          const w = maxBuildingSize * (0.7 + Math.random() * 0.3);
          const h = maxBuildingSize * (0.7 + Math.random() * 0.3);
          buildings.push({
            x: bx + ROAD_WIDTH / 2 + margin + (maxBuildingSize - w) / 2,
            y: by + ROAD_WIDTH / 2 + margin + (maxBuildingSize - h) / 2,
            w,
            h,
            color: buildingColors[Math.floor(Math.random() * buildingColors.length)],
            roofColor: roofColors[Math.floor(Math.random() * roofColors.length)],
            height: 40 + Math.random() * 100,
          });
        } else {
          for (let sx = 0; sx < subdivisions; sx++) {
            for (let sy = 0; sy < subdivisions; sy++) {
              if (Math.random() > 0.2) {
                const subW = (maxBuildingSize / subdivisions) * (0.7 + Math.random() * 0.25);
                const subH = (maxBuildingSize / subdivisions) * (0.7 + Math.random() * 0.25);
                const subX = bx + ROAD_WIDTH / 2 + margin + (sx * maxBuildingSize) / subdivisions + ((maxBuildingSize / subdivisions - subW) / 2);
                const subY = by + ROAD_WIDTH / 2 + margin + (sy * maxBuildingSize) / subdivisions + ((maxBuildingSize / subdivisions - subH) / 2);
                buildings.push({
                  x: subX,
                  y: subY,
                  w: subW,
                  h: subH,
                  color: buildingColors[Math.floor(Math.random() * buildingColors.length)],
                  roofColor: roofColors[Math.floor(Math.random() * roofColors.length)],
                  height: 30 + Math.random() * 80,
                });
              }
            }
          }
        }
      }
    }
  }

  // Place traffic cones at some intersections
  for (let bx = -CITY_SIZE / 2; bx < CITY_SIZE / 2; bx += BLOCK_SIZE) {
    for (let by = -CITY_SIZE / 2; by < CITY_SIZE / 2; by += BLOCK_SIZE) {
      if (Math.random() > 0.6) {
        const cx = bx + ROAD_WIDTH / 2;
        const cy = by + ROAD_WIDTH / 2;
        const numCones = 3 + Math.floor(Math.random() * 5);
        for (let i = 0; i < numCones; i++) {
          const angle = (Math.PI * 2 * i) / numCones;
          const radius = 20 + Math.random() * 30;
          cones.push({
            x: cx + Math.cos(angle) * radius,
            y: cy + Math.sin(angle) * radius,
            hit: false,
          });
        }
      }
    }
  }

  return { buildings, cones };
}

export function isOnRoad(x: number, y: number): boolean {
  const nx = ((x % BLOCK_SIZE) + BLOCK_SIZE) % BLOCK_SIZE;
  const ny = ((y % BLOCK_SIZE) + BLOCK_SIZE) % BLOCK_SIZE;
  return nx < ROAD_WIDTH || ny < ROAD_WIDTH;
}

export function checkBuildingCollision(
  x: number,
  y: number,
  carWidth: number,
  carHeight: number,
  angle: number,
  buildings: Building[]
): { collided: boolean; pushX: number; pushY: number } {
  const corners = getCarCorners(x, y, carWidth, carHeight, angle);
  let pushX = 0;
  let pushY = 0;
  let collided = false;

  for (const building of buildings) {
    for (const corner of corners) {
      if (
        corner.x >= building.x &&
        corner.x <= building.x + building.w &&
        corner.y >= building.y &&
        corner.y <= building.y + building.h
      ) {
        collided = true;
        const cx = building.x + building.w / 2;
        const cy = building.y + building.h / 2;
        const dx = corner.x - cx;
        const dy = corner.y - cy;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        pushX += (dx / dist) * 3;
        pushY += (dy / dist) * 3;
      }
    }
  }

  return { collided, pushX, pushY };
}

function getCarCorners(x: number, y: number, w: number, h: number, angle: number) {
  const cos = Math.cos(angle);
  const sin = Math.sin(angle);
  const hw = w / 2;
  const hh = h / 2;

  return [
    { x: x + cos * hw - sin * hh, y: y + sin * hw + cos * hh },
    { x: x + cos * hw + sin * hh, y: y + sin * hw - cos * hh },
    { x: x - cos * hw - sin * hh, y: y - sin * hw + cos * hh },
    { x: x - cos * hw + sin * hh, y: y - sin * hw - cos * hh },
  ];
}

export { CITY_SIZE, ROAD_WIDTH, BLOCK_SIZE };

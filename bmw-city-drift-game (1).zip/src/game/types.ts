export interface CarSpec {
  id: string;
  name: string;
  series: string;
  year: string;
  color: string;
  bodyColor: string;
  accentColor: string;
  maxSpeed: number;
  acceleration: number;
  driftFactor: number;
  grip: number;
  weight: number;
  hp: number;
  torque: string;
  engine: string;
  description: string;
}

export interface CarState {
  x: number;
  y: number;
  angle: number;
  speed: number;
  angularVelocity: number;
  drifting: boolean;
  driftAngle: number;
  steerAngle: number;
  throttle: number;
  brake: number;
  handbrake: boolean;
}

export interface TireSmoke {
  x: number;
  y: number;
  alpha: number;
  size: number;
  vx: number;
  vy: number;
  life: number;
}

export interface SkidMark {
  x: number;
  y: number;
  angle: number;
  alpha: number;
  width: number;
}

export interface Building {
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  roofColor: string;
  height: number;
}

export interface TrafficCone {
  x: number;
  y: number;
  hit: boolean;
}

export interface GameState {
  car: CarState;
  score: number;
  driftScore: number;
  driftMultiplier: number;
  driftCombo: number;
  maxDriftCombo: number;
  totalDriftScore: number;
  time: number;
  cameraX: number;
  cameraY: number;
  smokeParticles: TireSmoke[];
  skidMarks: SkidMark[];
  buildings: Building[];
  cones: TrafficCone[];
  sparks: Spark[];
}

export interface Spark {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  alpha: number;
  color: string;
}

export interface InputState {
  up: boolean;
  down: boolean;
  left: boolean;
  right: boolean;
  handbrake: boolean;
  nitro: boolean;
}

export type GameScreen = 'menu' | 'select' | 'game' | 'paused' | 'gameover';

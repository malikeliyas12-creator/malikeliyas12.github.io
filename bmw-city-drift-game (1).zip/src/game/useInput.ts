import { useRef, useEffect, useCallback } from 'react';
import { InputState } from './types';

export function useInput() {
  const inputRef = useRef<InputState>({
    up: false,
    down: false,
    left: false,
    right: false,
    handbrake: false,
    nitro: false,
  });

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowUp':
      case 'w':
      case 'W':
        inputRef.current.up = true;
        e.preventDefault();
        break;
      case 'ArrowDown':
      case 's':
      case 'S':
        inputRef.current.down = true;
        e.preventDefault();
        break;
      case 'ArrowLeft':
      case 'a':
      case 'A':
        inputRef.current.left = true;
        e.preventDefault();
        break;
      case 'ArrowRight':
      case 'd':
      case 'D':
        inputRef.current.right = true;
        e.preventDefault();
        break;
      case ' ':
        inputRef.current.handbrake = true;
        e.preventDefault();
        break;
      case 'Shift':
        inputRef.current.nitro = true;
        e.preventDefault();
        break;
    }
  }, []);

  const handleKeyUp = useCallback((e: KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowUp':
      case 'w':
      case 'W':
        inputRef.current.up = false;
        break;
      case 'ArrowDown':
      case 's':
      case 'S':
        inputRef.current.down = false;
        break;
      case 'ArrowLeft':
      case 'a':
      case 'A':
        inputRef.current.left = false;
        break;
      case 'ArrowRight':
      case 'd':
      case 'D':
        inputRef.current.right = false;
        break;
      case ' ':
        inputRef.current.handbrake = false;
        break;
      case 'Shift':
        inputRef.current.nitro = false;
        break;
    }
  }, []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleKeyDown, handleKeyUp]);

  return inputRef;
}

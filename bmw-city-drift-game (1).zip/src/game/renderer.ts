import { CarState, TireSmoke, SkidMark, Building, TrafficCone, Spark, CarSpec } from './types';
import { CITY_SIZE, ROAD_WIDTH, BLOCK_SIZE } from './city';
import { CAR_WIDTH, CAR_HEIGHT } from './physics';

export function renderGame(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  car: CarState,
  spec: CarSpec,
  cameraX: number,
  cameraY: number,
  buildings: Building[],
  smokeParticles: TireSmoke[],
  skidMarks: SkidMark[],
  cones: TrafficCone[],
  sparks: Spark[],
  zoom: number
) {
  const w = canvas.width;
  const h = canvas.height;

  ctx.save();
  ctx.clearRect(0, 0, w, h);

  // Background
  ctx.fillStyle = '#0a0a0a';
  ctx.fillRect(0, 0, w, h);

  // Camera transform
  ctx.translate(w / 2, h / 2);
  ctx.scale(zoom, zoom);
  ctx.translate(-cameraX, -cameraY);

  // Draw city
  drawRoads(ctx, cameraX, cameraY, w / zoom, h / zoom);
  drawSkidMarks(ctx, skidMarks);
  drawBuildings(ctx, buildings, cameraX, cameraY, w / zoom, h / zoom);
  drawCones(ctx, cones, cameraX, cameraY, w / zoom, h / zoom);
  drawCar(ctx, car, spec);
  drawSmoke(ctx, smokeParticles);
  drawSparks(ctx, sparks);

  // Map border
  ctx.strokeStyle = '#FF4444';
  ctx.lineWidth = 4;
  ctx.strokeRect(-CITY_SIZE / 2, -CITY_SIZE / 2, CITY_SIZE, CITY_SIZE);

  ctx.restore();
}

function drawRoads(
  ctx: CanvasRenderingContext2D,
  camX: number,
  camY: number,
  viewW: number,
  viewH: number
) {
  const margin = 500;
  const left = camX - viewW / 2 - margin;
  const right = camX + viewW / 2 + margin;
  const top = camY - viewH / 2 - margin;
  const bottom = camY + viewH / 2 + margin;

  // Road base
  ctx.fillStyle = '#1a1a2e';

  // Draw horizontal roads
  for (let by = -CITY_SIZE / 2; by < CITY_SIZE / 2; by += BLOCK_SIZE) {
    if (by + ROAD_WIDTH < top || by > bottom) continue;
    ctx.fillRect(
      Math.max(left, -CITY_SIZE / 2),
      by,
      Math.min(right, CITY_SIZE / 2) - Math.max(left, -CITY_SIZE / 2),
      ROAD_WIDTH
    );
  }

  // Draw vertical roads
  for (let bx = -CITY_SIZE / 2; bx < CITY_SIZE / 2; bx += BLOCK_SIZE) {
    if (bx + ROAD_WIDTH < left || bx > right) continue;
    ctx.fillRect(
      bx,
      Math.max(top, -CITY_SIZE / 2),
      ROAD_WIDTH,
      Math.min(bottom, CITY_SIZE / 2) - Math.max(top, -CITY_SIZE / 2)
    );
  }

  // Road markings - center lines
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 2;
  ctx.setLineDash([20, 20]);

  // Horizontal center lines
  for (let by = -CITY_SIZE / 2; by < CITY_SIZE / 2; by += BLOCK_SIZE) {
    if (by + ROAD_WIDTH < top || by > bottom) continue;
    ctx.beginPath();
    ctx.moveTo(Math.max(left, -CITY_SIZE / 2), by + ROAD_WIDTH / 2);
    ctx.lineTo(Math.min(right, CITY_SIZE / 2), by + ROAD_WIDTH / 2);
    ctx.stroke();
  }

  // Vertical center lines
  for (let bx = -CITY_SIZE / 2; bx < CITY_SIZE / 2; bx += BLOCK_SIZE) {
    if (bx + ROAD_WIDTH < left || bx > right) continue;
    ctx.beginPath();
    ctx.moveTo(bx + ROAD_WIDTH / 2, Math.max(top, -CITY_SIZE / 2));
    ctx.lineTo(bx + ROAD_WIDTH / 2, Math.min(bottom, CITY_SIZE / 2));
    ctx.stroke();
  }

  ctx.setLineDash([]);

  // Road edge lines
  ctx.strokeStyle = '#FFFFFF33';
  ctx.lineWidth = 1;

  for (let by = -CITY_SIZE / 2; by < CITY_SIZE / 2; by += BLOCK_SIZE) {
    if (by + ROAD_WIDTH < top || by > bottom) continue;
    ctx.beginPath();
    ctx.moveTo(Math.max(left, -CITY_SIZE / 2), by + 2);
    ctx.lineTo(Math.min(right, CITY_SIZE / 2), by + 2);
    ctx.moveTo(Math.max(left, -CITY_SIZE / 2), by + ROAD_WIDTH - 2);
    ctx.lineTo(Math.min(right, CITY_SIZE / 2), by + ROAD_WIDTH - 2);
    ctx.stroke();
  }

  for (let bx = -CITY_SIZE / 2; bx < CITY_SIZE / 2; bx += BLOCK_SIZE) {
    if (bx + ROAD_WIDTH < left || bx > right) continue;
    ctx.beginPath();
    ctx.moveTo(bx + 2, Math.max(top, -CITY_SIZE / 2));
    ctx.lineTo(bx + 2, Math.min(bottom, CITY_SIZE / 2));
    ctx.moveTo(bx + ROAD_WIDTH - 2, Math.max(top, -CITY_SIZE / 2));
    ctx.lineTo(bx + ROAD_WIDTH - 2, Math.min(bottom, CITY_SIZE / 2));
    ctx.stroke();
  }
}

function drawBuildings(
  ctx: CanvasRenderingContext2D,
  buildings: Building[],
  camX: number,
  camY: number,
  viewW: number,
  viewH: number
) {
  const margin = 300;

  for (const b of buildings) {
    if (
      b.x + b.w < camX - viewW / 2 - margin ||
      b.x > camX + viewW / 2 + margin ||
      b.y + b.h < camY - viewH / 2 - margin ||
      b.y > camY + viewH / 2 + margin
    ) continue;

    // Building shadow
    ctx.fillStyle = '#00000044';
    ctx.fillRect(b.x + 4, b.y + 4, b.w, b.h);

    // Building body
    ctx.fillStyle = b.color;
    ctx.fillRect(b.x, b.y, b.w, b.h);

    // Building edge highlight
    ctx.strokeStyle = '#FFFFFF15';
    ctx.lineWidth = 1;
    ctx.strokeRect(b.x, b.y, b.w, b.h);

    // Windows
    const windowSize = 6;
    const windowGap = 14;
    ctx.fillStyle = '#FFD70033';

    for (let wx = b.x + 8; wx < b.x + b.w - 8; wx += windowGap) {
      for (let wy = b.y + 8; wy < b.y + b.h - 8; wy += windowGap) {
        if (Math.random() > 0.3) {
          const lit = Math.random() > 0.4;
          ctx.fillStyle = lit ? '#FFD70066' : '#FFFFFF11';
          ctx.fillRect(wx, wy, windowSize, windowSize);
        }
      }
    }

    // Roof accent
    ctx.fillStyle = b.roofColor + '33';
    ctx.fillRect(b.x, b.y, b.w, 3);
  }
}

function drawCar(ctx: CanvasRenderingContext2D, car: CarState, spec: CarSpec) {
  ctx.save();
  ctx.translate(car.x, car.y);
  ctx.rotate(car.angle);

  const w = CAR_WIDTH;
  const h = CAR_HEIGHT;

  // Car shadow
  ctx.fillStyle = '#00000066';
  ctx.beginPath();
  ctx.roundRect(-w / 2 + 3, -h / 2 + 3, w, h, 4);
  ctx.fill();

  // Car body
  ctx.fillStyle = spec.bodyColor;
  ctx.beginPath();
  ctx.roundRect(-w / 2, -h / 2, w, h, 4);
  ctx.fill();

  // Car body gradient overlay
  const gradient = ctx.createLinearGradient(-w / 2, 0, w / 2, 0);
  gradient.addColorStop(0, '#FFFFFF22');
  gradient.addColorStop(0.5, '#FFFFFF00');
  gradient.addColorStop(1, '#00000022');
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.roundRect(-w / 2, -h / 2, w, h, 4);
  ctx.fill();

  // Windshield
  ctx.fillStyle = '#1a1a2eCC';
  ctx.beginPath();
  ctx.roundRect(-w / 2 + 3, -h / 2 + 6, w - 6, 10, 2);
  ctx.fill();

  // Rear window
  ctx.fillStyle = '#1a1a2eAA';
  ctx.beginPath();
  ctx.roundRect(-w / 2 + 4, h / 2 - 14, w - 8, 8, 2);
  ctx.fill();

  // Headlights
  ctx.fillStyle = '#FFFFFFEE';
  ctx.shadowColor = '#FFFFFF';
  ctx.shadowBlur = 8;
  ctx.fillRect(-w / 2 + 2, -h / 2 + 1, 4, 3);
  ctx.fillRect(w / 2 - 6, -h / 2 + 1, 4, 3);
  ctx.shadowBlur = 0;

  // Tail lights
  ctx.fillStyle = '#FF0000DD';
  ctx.shadowColor = '#FF0000';
  ctx.shadowBlur = 6;
  ctx.fillRect(-w / 2 + 2, h / 2 - 4, 5, 2);
  ctx.fillRect(w / 2 - 7, h / 2 - 4, 5, 2);
  ctx.shadowBlur = 0;

  // BMW kidney grille
  ctx.fillStyle = '#111111';
  ctx.fillRect(-4, -h / 2 + 2, 3, 4);
  ctx.fillRect(1, -h / 2 + 2, 3, 4);

  // Side mirrors
  ctx.fillStyle = spec.bodyColor;
  ctx.fillRect(-w / 2 - 2, -4, 3, 4);
  ctx.fillRect(w / 2 - 1, -4, 3, 4);

  // Car outline
  ctx.strokeStyle = '#FFFFFF33';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.roundRect(-w / 2, -h / 2, w, h, 4);
  ctx.stroke();

  // Headlight beam (when moving)
  if (Math.abs(car.speed) > 0.5) {
    const beamGrad = ctx.createRadialGradient(0, -h / 2, 5, 0, -h / 2 - 80, 60);
    beamGrad.addColorStop(0, '#FFFF9922');
    beamGrad.addColorStop(1, '#FFFF9900');
    ctx.fillStyle = beamGrad;
    ctx.beginPath();
    ctx.moveTo(-w / 2, -h / 2);
    ctx.lineTo(-w / 2 - 30, -h / 2 - 100);
    ctx.lineTo(w / 2 + 30, -h / 2 - 100);
    ctx.lineTo(w / 2, -h / 2);
    ctx.fill();
  }

  ctx.restore();
}

function drawSmoke(ctx: CanvasRenderingContext2D, particles: TireSmoke[]) {
  for (const p of particles) {
    ctx.fillStyle = `rgba(200, 200, 200, ${p.alpha})`;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawSkidMarks(ctx: CanvasRenderingContext2D, marks: SkidMark[]) {
  for (const m of marks) {
    ctx.fillStyle = `rgba(30, 30, 30, ${m.alpha})`;
    ctx.save();
    ctx.translate(m.x, m.y);
    ctx.rotate(m.angle);
    ctx.fillRect(-m.width / 2, -2, m.width, 4);
    ctx.restore();
  }
}

function drawCones(
  ctx: CanvasRenderingContext2D,
  cones: TrafficCone[],
  camX: number,
  camY: number,
  viewW: number,
  viewH: number
) {
  for (const c of cones) {
    if (
      Math.abs(c.x - camX) > viewW / 2 + 50 ||
      Math.abs(c.y - camY) > viewH / 2 + 50
    ) continue;

    if (c.hit) continue;

    ctx.fillStyle = '#FF6600';
    ctx.beginPath();
    ctx.moveTo(c.x, c.y - 8);
    ctx.lineTo(c.x - 5, c.y + 5);
    ctx.lineTo(c.x + 5, c.y + 5);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(c.x - 3, c.y - 2, 6, 2);
  }
}

function drawSparks(ctx: CanvasRenderingContext2D, sparks: Spark[]) {
  for (const s of sparks) {
    ctx.fillStyle = s.color;
    ctx.globalAlpha = s.alpha;
    ctx.fillRect(s.x - 1, s.y - 1, 2, 2);
  }
  ctx.globalAlpha = 1;
}

export function renderMinimap(
  ctx: CanvasRenderingContext2D,
  carX: number,
  carY: number,
  carAngle: number,
  buildings: Building[],
  mapSize: number,
  x: number,
  y: number
) {
  const scale = mapSize / CITY_SIZE;

  ctx.save();
  ctx.translate(x, y);

  // Background
  ctx.fillStyle = '#0a0a0aCC';
  ctx.strokeStyle = '#FFD70066';
  ctx.lineWidth = 2;
  ctx.fillRect(0, 0, mapSize, mapSize);
  ctx.strokeRect(0, 0, mapSize, mapSize);

  // Roads
  ctx.fillStyle = '#1a1a2e88';
  for (let bx = -CITY_SIZE / 2; bx < CITY_SIZE / 2; bx += BLOCK_SIZE) {
    ctx.fillRect(
      (bx + CITY_SIZE / 2) * scale,
      0,
      ROAD_WIDTH * scale,
      mapSize
    );
  }
  for (let by = -CITY_SIZE / 2; by < CITY_SIZE / 2; by += BLOCK_SIZE) {
    ctx.fillRect(
      0,
      (by + CITY_SIZE / 2) * scale,
      mapSize,
      ROAD_WIDTH * scale
    );
  }

  // Buildings
  ctx.fillStyle = '#34495E88';
  for (const b of buildings) {
    ctx.fillRect(
      (b.x + CITY_SIZE / 2) * scale,
      (b.y + CITY_SIZE / 2) * scale,
      b.w * scale,
      b.h * scale
    );
  }

  // Player
  const px = (carX + CITY_SIZE / 2) * scale;
  const py = (carY + CITY_SIZE / 2) * scale;

  ctx.fillStyle = '#FF4444';
  ctx.save();
  ctx.translate(px, py);
  ctx.rotate(carAngle);
  ctx.beginPath();
  ctx.moveTo(0, -4);
  ctx.lineTo(-3, 3);
  ctx.lineTo(3, 3);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  ctx.restore();
}

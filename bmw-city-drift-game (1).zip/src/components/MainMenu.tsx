import React, { useEffect, useRef } from 'react';

interface MainMenuProps {
  onPlay: () => void;
}

const MainMenu: React.FC<MainMenuProps> = ({ onPlay }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Animated background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    let animId = 0;

    const particles: {
      x: number; y: number; vx: number; vy: number;
      size: number; alpha: number; color: string;
    }[] = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const animate = () => {
      frame++;
      const w = canvas.width;
      const h = canvas.height;

      // Clear
      ctx.fillStyle = '#0a0a0f';
      ctx.fillRect(0, 0, w, h);

      // Grid
      ctx.strokeStyle = '#1a1a3e22';
      ctx.lineWidth = 1;
      const gridSize = 60;
      const offset = (frame * 0.5) % gridSize;

      for (let x = -gridSize + offset; x < w + gridSize; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = -gridSize + offset; y < h + gridSize; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Spawn particles
      if (frame % 3 === 0) {
        particles.push({
          x: Math.random() * w,
          y: h + 10,
          vx: (Math.random() - 0.5) * 2,
          vy: -(1 + Math.random() * 3),
          size: 1 + Math.random() * 3,
          alpha: 0.3 + Math.random() * 0.5,
          color: ['#3B82F6', '#F59E0B', '#EF4444', '#22C55E', '#A855F7'][Math.floor(Math.random() * 5)],
        });
      }

      // Update & draw particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= 0.003;
        if (p.alpha <= 0 || p.y < -10) {
          particles.splice(i, 1);
          continue;
        }
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // Limit particles
      if (particles.length > 150) {
        particles.splice(0, particles.length - 150);
      }

      // Center glow
      const glow = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w * 0.5);
      glow.addColorStop(0, '#1E40AF08');
      glow.addColorStop(0.5, '#1E40AF04');
      glow.addColorStop(1, 'transparent');
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, w, h);

      animId = requestAnimationFrame(animate);
    };

    animId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

      {/* Background image overlay */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: 'url(/images/hero-bg.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/80" />

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4">
        {/* Logo */}
        <div className="text-center mb-12 animate-fade-in">
          {/* BMW Logo */}
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 rounded-full border-4 border-white/20 bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center shadow-2xl shadow-blue-600/30">
              <svg width="60" height="60" viewBox="0 0 60 60">
                <circle cx="30" cy="30" r="28" fill="none" stroke="white" strokeWidth="2" opacity="0.8" />
                <circle cx="30" cy="30" r="22" fill="none" stroke="white" strokeWidth="1" opacity="0.4" />
                {/* BMW quadrants */}
                <path d="M30 8 A22 22 0 0 1 52 30 L30 30 Z" fill="#4A90D9" />
                <path d="M30 52 A22 22 0 0 1 8 30 L30 30 Z" fill="#4A90D9" />
                <path d="M52 30 A22 22 0 0 1 30 52 L30 30 Z" fill="white" opacity="0.9" />
                <path d="M8 30 A22 22 0 0 1 30 8 L30 30 Z" fill="white" opacity="0.9" />
                <text x="30" y="34" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold" fontFamily="sans-serif">BMW</text>
              </svg>
            </div>
          </div>

          <h1 className="text-7xl md:text-8xl font-black text-white tracking-tighter mb-2">
            CITY <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">DRIFT</span>
          </h1>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-blue-500" />
            <span className="text-blue-400 text-sm font-bold tracking-[0.3em]">BMW EDITION</span>
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-blue-500" />
          </div>
          <p className="text-gray-400 text-lg max-w-md mx-auto">
            Choose your BMW. Master the drift. Own the city streets.
          </p>
        </div>

        {/* Buttons */}
        <div className="flex flex-col gap-4 w-full max-w-sm">
          <button
            onClick={onPlay}
            className="group relative w-full py-5 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-black text-xl rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-blue-600/30 active:scale-95 overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            <span className="relative flex items-center justify-center gap-3">
              🏁 START RACING
            </span>
          </button>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 text-center">
              <div className="text-3xl font-black text-white">16</div>
              <div className="text-gray-500 text-xs font-bold">BMW MODELS</div>
            </div>
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 text-center">
              <div className="text-3xl font-black text-white">FREE</div>
              <div className="text-gray-500 text-xs font-bold">TO PLAY</div>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="mt-12 grid grid-cols-3 gap-6 max-w-lg">
          {[
            { icon: '🏙️', label: 'Open City' },
            { icon: '💨', label: 'Drift Physics' },
            { icon: '🏆', label: 'Score System' },
          ].map((f) => (
            <div key={f.label} className="text-center">
              <div className="text-3xl mb-1">{f.icon}</div>
              <div className="text-gray-400 text-xs font-bold">{f.label}</div>
            </div>
          ))}
        </div>

        {/* Controls */}
        <div className="mt-12 text-center">
          <div className="text-gray-600 text-xs font-mono space-y-1">
            <div>WASD / Arrow Keys to Drive · SPACE for Handbrake</div>
            <div>ESC to Pause · Build drift combos for high scores!</div>
          </div>
        </div>
      </div>

      {/* Bottom gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent" />
    </div>
  );
};

export default MainMenu;

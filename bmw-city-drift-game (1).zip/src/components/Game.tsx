import React, { useRef, useEffect, useCallback, useState } from 'react';
import { CarSpec, TireSmoke, SkidMark, Building, TrafficCone, Spark } from '../game/types';
import { initCarState, updateCar } from '../game/physics';
import { generateCity } from '../game/city';
import { renderGame, renderMinimap } from '../game/renderer';
import { useGameLoop } from '../game/useGameLoop';
import { useInput } from '../game/useInput';

interface GameProps {
  car: CarSpec;
  onBack: () => void;
}

const Game: React.FC<GameProps> = ({ car, onBack }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const inputRef = useInput();
  const [score, setScore] = useState(0);
  const [driftCombo, setDriftCombo] = useState(0);
  const [driftMultiplier, setDriftMultiplier] = useState(1);
  const [speed, setSpeed] = useState(0);
  const [time, setTime] = useState(0);
  const [currentDriftScore, setCurrentDriftScore] = useState(0);
  const [showDriftText, setShowDriftText] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  // Touch controls
  const touchRef = useRef({
    up: false,
    down: false,
    left: false,
    right: false,
    handbrake: false,
  });

  const gameStateRef = useRef({
    car: initCarState(),
    cameraX: 60,
    cameraY: 60,
    smokeParticles: [] as TireSmoke[],
    skidMarks: [] as SkidMark[],
    sparks: [] as Spark[],
    buildings: [] as Building[],
    cones: [] as TrafficCone[],
    score: 0,
    driftScore: 0,
    driftMultiplier: 1,
    driftCombo: 0,
    driftTimer: 0,
    time: 0,
    zoom: 1.5,
    initialized: false,
  });

  // Initialize city
  useEffect(() => {
    const { buildings, cones } = generateCity();
    gameStateRef.current.buildings = buildings;
    gameStateRef.current.cones = cones;
    gameStateRef.current.initialized = true;
  }, []);

  // Pause handler
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') {
        setIsPaused(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  const gameLoop = useCallback((dt: number) => {
    const gs = gameStateRef.current;
    if (!gs.initialized) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas
    if (canvas.width !== window.innerWidth || canvas.height !== window.innerHeight) {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    // Merge touch + keyboard input
    const mergedInput = {
      up: inputRef.current.up || touchRef.current.up,
      down: inputRef.current.down || touchRef.current.down,
      left: inputRef.current.left || touchRef.current.left,
      right: inputRef.current.right || touchRef.current.right,
      handbrake: inputRef.current.handbrake || touchRef.current.handbrake,
      nitro: inputRef.current.nitro,
    };

    // Update physics
    const result = updateCar(gs.car, mergedInput, car, dt, gs.buildings, gs.cones);
    gs.car = result.car;

    // Update smoke particles
    gs.smokeParticles.push(...result.smoke);
    gs.smokeParticles = gs.smokeParticles.filter(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= 0.008;
      p.size += 0.3;
      p.life--;
      return p.life > 0 && p.alpha > 0;
    });

    // Limit particles
    if (gs.smokeParticles.length > 200) {
      gs.smokeParticles = gs.smokeParticles.slice(-200);
    }

    // Update skid marks
    gs.skidMarks.push(...result.skids);
    if (gs.skidMarks.length > 2000) {
      gs.skidMarks = gs.skidMarks.slice(-2000);
    }

    // Update sparks
    gs.sparks.push(...result.sparks);
    gs.sparks = gs.sparks.filter(s => {
      s.x += s.vx;
      s.y += s.vy;
      s.vx *= 0.95;
      s.vy *= 0.95;
      s.life--;
      s.alpha = s.life / 40;
      return s.life > 0;
    });

    // Drift scoring
    if (result.isDrifting && result.driftAmount > 0.1) {
      gs.driftScore += result.driftAmount * 10 * gs.driftMultiplier;
      gs.driftTimer = 60;
      gs.driftCombo++;

      if (gs.driftCombo > 30) gs.driftMultiplier = 2;
      if (gs.driftCombo > 100) gs.driftMultiplier = 3;
      if (gs.driftCombo > 200) gs.driftMultiplier = 4;
      if (gs.driftCombo > 400) gs.driftMultiplier = 5;

      setCurrentDriftScore(Math.floor(gs.driftScore));
      setShowDriftText(true);
    } else {
      gs.driftTimer--;
      if (gs.driftTimer <= 0 && gs.driftScore > 0) {
        gs.score += Math.floor(gs.driftScore);
        gs.driftScore = 0;
        gs.driftCombo = 0;
        gs.driftMultiplier = 1;
        setShowDriftText(false);
      }
    }

    // Time
    gs.time += dt;

    // Camera follow with smoothing
    const camLag = 0.08;
    const lookAhead = 80;
    const targetX = gs.car.x + Math.sin(gs.car.angle) * lookAhead * (gs.car.speed / car.maxSpeed);
    const targetY = gs.car.y - Math.cos(gs.car.angle) * lookAhead * (gs.car.speed / car.maxSpeed);
    gs.cameraX += (targetX - gs.cameraX) * camLag;
    gs.cameraY += (targetY - gs.cameraY) * camLag;

    // Dynamic zoom
    const speedRatio = Math.abs(gs.car.speed) / car.maxSpeed;
    const targetZoom = 1.8 - speedRatio * 0.5;
    gs.zoom += (targetZoom - gs.zoom) * 0.02;

    // Render
    renderGame(
      ctx, canvas,
      gs.car, car,
      gs.cameraX, gs.cameraY,
      gs.buildings,
      gs.smokeParticles,
      gs.skidMarks,
      gs.cones,
      gs.sparks,
      gs.zoom
    );

    // Render minimap
    renderMinimap(
      ctx,
      gs.car.x, gs.car.y, gs.car.angle,
      gs.buildings,
      140,
      canvas.width - 160,
      canvas.height - 160
    );

    // Update React state for HUD (throttled)
    setScore(gs.score);
    setDriftCombo(gs.driftCombo);
    setDriftMultiplier(gs.driftMultiplier);
    setSpeed(Math.abs(gs.car.speed));
    setTime(gs.time);
  }, [car, inputRef]);

  useGameLoop(gameLoop, !isPaused);

  const formatTime = (t: number) => {
    const mins = Math.floor(t / 60);
    const secs = Math.floor(t % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const speedKmh = Math.floor(speed * 20);

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full" />

      {/* HUD */}
      <div className="absolute top-0 left-0 right-0 pointer-events-none">
        {/* Top bar */}
        <div className="flex justify-between items-start p-4">
          {/* Score */}
          <div className="bg-black/60 backdrop-blur-sm rounded-xl p-3 border border-white/10">
            <div className="text-yellow-400 text-xs font-bold tracking-widest">SCORE</div>
            <div className="text-white text-3xl font-black tabular-nums">{score.toLocaleString()}</div>
          </div>

          {/* Time */}
          <div className="bg-black/60 backdrop-blur-sm rounded-xl p-3 border border-white/10 text-center">
            <div className="text-blue-400 text-xs font-bold tracking-widest">TIME</div>
            <div className="text-white text-2xl font-black tabular-nums">{formatTime(time)}</div>
          </div>

          {/* Car Info */}
          <div className="bg-black/60 backdrop-blur-sm rounded-xl p-3 border border-white/10 text-right pointer-events-auto">
            <div className="text-gray-400 text-xs font-bold tracking-widest">BMW {car.name}</div>
            <button
              onClick={onBack}
              className="text-red-400 text-xs mt-1 hover:text-red-300 transition-colors cursor-pointer"
            >
              ← BACK TO MENU
            </button>
          </div>
        </div>
      </div>

      {/* Drift Score Popup */}
      {showDriftText && currentDriftScore > 0 && (
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 pointer-events-none text-center">
          <div className={`text-5xl font-black transition-all duration-200 ${
            driftMultiplier >= 4 ? 'text-red-400 animate-pulse scale-125' :
            driftMultiplier >= 3 ? 'text-orange-400 animate-pulse scale-110' :
            driftMultiplier >= 2 ? 'text-yellow-400 scale-105' :
            'text-white'
          }`}>
            +{currentDriftScore.toLocaleString()}
          </div>
          {driftMultiplier > 1 && (
            <div className="text-2xl font-black text-yellow-300 mt-1">
              x{driftMultiplier} MULTIPLIER!
            </div>
          )}
          {driftCombo > 50 && (
            <div className="text-lg font-bold text-orange-300 mt-1 animate-bounce">
              {driftCombo > 300 ? '🔥 LEGENDARY DRIFT!' :
               driftCombo > 200 ? '🔥 INSANE DRIFT!' :
               driftCombo > 100 ? '🔥 AMAZING DRIFT!' :
               '🔥 GREAT DRIFT!'}
            </div>
          )}
        </div>
      )}

      {/* Bottom HUD */}
      <div className="absolute bottom-0 left-0 right-0 pointer-events-none">
        <div className="flex justify-between items-end p-4">
          {/* Speed */}
          <div className="bg-black/60 backdrop-blur-sm rounded-xl p-4 border border-white/10">
            <div className="text-gray-400 text-xs font-bold tracking-widest mb-1">SPEED</div>
            <div className="flex items-baseline gap-1">
              <span className="text-white text-4xl font-black tabular-nums">{speedKmh}</span>
              <span className="text-gray-400 text-sm font-bold">KM/H</span>
            </div>
            {/* Speed bar */}
            <div className="w-40 h-2 bg-gray-800 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-100"
                style={{
                  width: `${(speed / car.maxSpeed) * 100}%`,
                  background: speedKmh > 200 ? 'linear-gradient(90deg, #EF4444, #F59E0B)' :
                             speedKmh > 100 ? 'linear-gradient(90deg, #F59E0B, #22C55E)' :
                             '#22C55E',
                }}
              />
            </div>
          </div>

          {/* Controls hint */}
          <div className="hidden md:block bg-black/40 backdrop-blur-sm rounded-xl p-3 border border-white/5 text-center">
            <div className="text-gray-500 text-[10px] font-mono space-y-0.5">
              <div>W/↑ Accelerate · S/↓ Brake</div>
              <div>A/↑ Steer Left · D/→ Steer Right</div>
              <div>SPACE Handbrake · ESC Pause</div>
            </div>
          </div>

          {/* Drift meter */}
          <div className="bg-black/60 backdrop-blur-sm rounded-xl p-4 border border-white/10 text-right">
            <div className="text-orange-400 text-xs font-bold tracking-widest mb-1">DRIFT COMBO</div>
            <div className="text-white text-3xl font-black tabular-nums">{driftCombo}</div>
            <div className="w-32 h-2 bg-gray-800 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-100"
                style={{
                  width: `${Math.min((driftCombo / 400) * 100, 100)}%`,
                  background: 'linear-gradient(90deg, #F97316, #EF4444, #A855F7)',
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Touch Controls */}
      <div className="md:hidden absolute bottom-0 left-0 right-0 pointer-events-auto" style={{ bottom: '100px' }}>
        <div className="flex justify-between px-4">
          {/* Left side - steering */}
          <div className="flex gap-2">
            <button
              className="w-16 h-16 bg-white/10 backdrop-blur rounded-xl flex items-center justify-center text-white text-2xl active:bg-white/30 select-none"
              onTouchStart={(e) => { e.preventDefault(); touchRef.current.left = true; }}
              onTouchEnd={() => { touchRef.current.left = false; }}
              onMouseDown={() => { touchRef.current.left = true; }}
              onMouseUp={() => { touchRef.current.left = false; }}
            >
              ◀
            </button>
            <button
              className="w-16 h-16 bg-white/10 backdrop-blur rounded-xl flex items-center justify-center text-white text-2xl active:bg-white/30 select-none"
              onTouchStart={(e) => { e.preventDefault(); touchRef.current.right = true; }}
              onTouchEnd={() => { touchRef.current.right = false; }}
              onMouseDown={() => { touchRef.current.right = true; }}
              onMouseUp={() => { touchRef.current.right = false; }}
            >
              ▶
            </button>
          </div>

          {/* Center - handbrake */}
          <button
            className="w-16 h-16 bg-red-500/30 backdrop-blur rounded-xl flex items-center justify-center text-white text-sm font-bold active:bg-red-500/60 select-none"
            onTouchStart={(e) => { e.preventDefault(); touchRef.current.handbrake = true; }}
            onTouchEnd={() => { touchRef.current.handbrake = false; }}
            onMouseDown={() => { touchRef.current.handbrake = true; }}
            onMouseUp={() => { touchRef.current.handbrake = false; }}
          >
            HB
          </button>

          {/* Right side - gas/brake */}
          <div className="flex gap-2">
            <button
              className="w-16 h-16 bg-red-500/20 backdrop-blur rounded-xl flex items-center justify-center text-red-400 text-2xl active:bg-red-500/40 select-none"
              onTouchStart={(e) => { e.preventDefault(); touchRef.current.down = true; }}
              onTouchEnd={() => { touchRef.current.down = false; }}
              onMouseDown={() => { touchRef.current.down = true; }}
              onMouseUp={() => { touchRef.current.down = false; }}
            >
              ▼
            </button>
            <button
              className="w-16 h-16 bg-green-500/20 backdrop-blur rounded-xl flex items-center justify-center text-green-400 text-2xl active:bg-green-500/40 select-none"
              onTouchStart={(e) => { e.preventDefault(); touchRef.current.up = true; }}
              onTouchEnd={() => { touchRef.current.up = false; }}
              onMouseDown={() => { touchRef.current.up = true; }}
              onMouseUp={() => { touchRef.current.up = false; }}
            >
              ▲
            </button>
          </div>
        </div>
      </div>

      {/* Pause Screen */}
      {isPaused && (
        <div className="absolute inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-50">
          <div className="text-center">
            <div className="text-6xl font-black text-white mb-4">PAUSED</div>
            <div className="text-gray-400 mb-8">Press ESC or P to resume</div>
            <div className="flex gap-4 justify-center">
              <button
                onClick={() => setIsPaused(false)}
                className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-colors pointer-events-auto"
              >
                RESUME
              </button>
              <button
                onClick={onBack}
                className="px-8 py-3 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded-xl transition-colors pointer-events-auto"
              >
                QUIT
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Game;

import React, { useState, useMemo } from 'react';
import { CarSpec } from '../game/types';
import { BMW_CARS } from '../game/cars';

interface CarSelectProps {
  onSelect: (car: CarSpec) => void;
  onBack: () => void;
}

const SERIES_FILTERS = ['All', '2 Series', '3 Series', '4 Series', '5 Series', '7 Series', '8 Series', 'Z Series', 'X Series', 'i Series', 'XM'];

const StatBar: React.FC<{ label: string; value: number; max: number; color: string }> = ({ label, value, max, color }) => (
  <div className="flex items-center gap-3">
    <span className="text-gray-400 text-xs font-bold w-24 text-right uppercase tracking-wider">{label}</span>
    <div className="flex-1 h-2.5 bg-gray-800 rounded-full overflow-hidden">
      <div
        className="h-full rounded-full transition-all duration-500 ease-out"
        style={{
          width: `${(value / max) * 100}%`,
          background: `linear-gradient(90deg, ${color}, ${color}CC)`,
          boxShadow: `0 0 8px ${color}66`,
        }}
      />
    </div>
    <span className="text-white text-xs font-bold w-12 tabular-nums">{Math.round((value / max) * 100)}</span>
  </div>
);

const CarSelect: React.FC<CarSelectProps> = ({ onSelect, onBack }) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [filter, setFilter] = useState('All');
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const filteredCars = useMemo(() => {
    if (filter === 'All') return BMW_CARS;
    return BMW_CARS.filter(c => c.series === filter);
  }, [filter]);
  
  // Make sure index stays in range
  React.useEffect(() => {
    if (selectedIndex >= filteredCars.length) {
      setSelectedIndex(0);
    }
  }, [filteredCars, selectedIndex]);

  const selectedCar = filteredCars[selectedIndex] || filteredCars[0];

  const drawCarPreview = (car: CarSpec, size: number = 200) => {
    const w = size * 0.35;
    const h = size * 0.7;
    const cx = size / 2;
    const cy = size / 2;

    return (
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {/* Glow */}
        <defs>
          <radialGradient id={`glow-${car.id}`}>
            <stop offset="0%" stopColor={car.bodyColor} stopOpacity="0.3" />
            <stop offset="100%" stopColor={car.bodyColor} stopOpacity="0" />
          </radialGradient>
          <filter id={`shadow-${car.id}`}>
            <feDropShadow dx="2" dy="4" stdDeviation="4" floodColor="#000000" floodOpacity="0.5" />
          </filter>
        </defs>

        {/* Ground glow */}
        <ellipse cx={cx} cy={cy + h * 0.4} rx={w * 1.2} ry={w * 0.3} fill={`url(#glow-${car.id})`} />

        {/* Car shadow */}
        <ellipse cx={cx + 3} cy={cy + 3} rx={w * 0.55} ry={h * 0.5} fill="#00000044" />

        {/* Car body */}
        <rect
          x={cx - w / 2}
          y={cy - h / 2}
          width={w}
          height={h}
          rx={6}
          fill={car.bodyColor}
          filter={`url(#shadow-${car.id})`}
        />

        {/* Body highlight */}
        <rect
          x={cx - w / 2}
          y={cy - h / 2}
          width={w / 2}
          height={h}
          rx={6}
          fill="#FFFFFF"
          opacity="0.1"
        />

        {/* Windshield */}
        <rect
          x={cx - w / 2 + 5}
          y={cy - h / 2 + 12}
          width={w - 10}
          height={h * 0.2}
          rx={3}
          fill="#1a1a2e"
          opacity="0.9"
        />

        {/* Rear window */}
        <rect
          x={cx - w / 2 + 7}
          y={cy + h / 2 - h * 0.22}
          width={w - 14}
          height={h * 0.15}
          rx={3}
          fill="#1a1a2e"
          opacity="0.7"
        />

        {/* Headlights */}
        <rect x={cx - w / 2 + 4} y={cy - h / 2 + 3} width={8} height={5} rx={1} fill="#FFFFFF" opacity="0.95" />
        <rect x={cx + w / 2 - 12} y={cy - h / 2 + 3} width={8} height={5} rx={1} fill="#FFFFFF" opacity="0.95" />

        {/* Headlight glow */}
        <circle cx={cx - w / 2 + 8} cy={cy - h / 2 + 5} r={6} fill="#FFFFFF" opacity="0.15" />
        <circle cx={cx + w / 2 - 8} cy={cy - h / 2 + 5} r={6} fill="#FFFFFF" opacity="0.15" />

        {/* Tail lights */}
        <rect x={cx - w / 2 + 4} y={cy + h / 2 - 8} width={10} height={4} rx={1} fill="#FF0000" opacity="0.9" />
        <rect x={cx + w / 2 - 14} y={cy + h / 2 - 8} width={10} height={4} rx={1} fill="#FF0000" opacity="0.9" />

        {/* Kidney grille */}
        <rect x={cx - 5} y={cy - h / 2 + 4} width={4} height={7} rx={1} fill="#111111" />
        <rect x={cx + 1} y={cy - h / 2 + 4} width={4} height={7} rx={1} fill="#111111" />

        {/* Side mirrors */}
        <rect x={cx - w / 2 - 4} y={cy - 3} width={5} height={6} rx={1} fill={car.bodyColor} />
        <rect x={cx + w / 2 - 1} y={cy - 3} width={5} height={6} rx={1} fill={car.bodyColor} />

        {/* Roof line */}
        <line x1={cx} y1={cy - h * 0.15} x2={cx} y2={cy + h * 0.15} stroke="#FFFFFF" strokeWidth="0.5" opacity="0.2" />

        {/* Car outline */}
        <rect
          x={cx - w / 2}
          y={cy - h / 2}
          width={w}
          height={h}
          rx={6}
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="0.5"
          opacity="0.3"
        />
      </svg>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 via-gray-900 to-black text-white">
      {/* Header */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 via-transparent to-blue-900/20" />
        <div className="relative max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors group"
            >
              <svg className="w-5 h-5 group-hover:-translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              <span className="font-medium">Back</span>
            </button>
            <div className="text-center">
              <h1 className="text-3xl font-black tracking-tight">
                SELECT YOUR <span className="text-blue-400">BMW</span>
              </h1>
              <p className="text-gray-500 text-sm mt-1">{filteredCars.length} models available</p>
            </div>
            <div className="w-20" />
          </div>
        </div>
      </div>

      {/* Series Filter */}
      <div className="max-w-7xl mx-auto px-4 mb-6">
        <div className="flex flex-wrap gap-2 justify-center">
          {SERIES_FILTERS.map(s => (
            <button
              key={s}
              onClick={() => { setFilter(s); setSelectedIndex(0); }}
              className={`px-4 py-1.5 rounded-full text-xs font-bold tracking-wider transition-all ${
                filter === s
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                  : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700/50 hover:text-white'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 pb-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Selected Car Details */}
          <div className="bg-gradient-to-br from-gray-800/40 to-gray-900/40 rounded-2xl p-6 border border-white/5 backdrop-blur-sm">
            {/* Car Preview */}
            <div className="flex justify-center mb-6 relative">
              <div className="absolute inset-0 flex items-center justify-center">
                <div
                  className="w-48 h-48 rounded-full blur-3xl opacity-20"
                  style={{ backgroundColor: selectedCar.bodyColor }}
                />
              </div>
              <div className="relative">
                {drawCarPreview(selectedCar, 240)}
              </div>
            </div>

            {/* Car Info */}
            <div className="text-center mb-6">
              <div className="flex items-center justify-center gap-2 mb-1">
                <div
                  className="w-4 h-4 rounded-full border-2 border-white/30"
                  style={{ backgroundColor: selectedCar.bodyColor }}
                />
                <h2 className="text-3xl font-black">BMW {selectedCar.name}</h2>
              </div>
              <p className="text-gray-500 text-sm">{selectedCar.year} · {selectedCar.series}</p>
            </div>

            {/* Specs */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-black/30 rounded-xl p-3 text-center">
                <div className="text-2xl font-black text-white">{selectedCar.hp}</div>
                <div className="text-gray-500 text-xs font-bold">HP</div>
              </div>
              <div className="bg-black/30 rounded-xl p-3 text-center">
                <div className="text-2xl font-black text-white">{selectedCar.torque}</div>
                <div className="text-gray-500 text-xs font-bold">TORQUE</div>
              </div>
              <div className="bg-black/30 rounded-xl p-3 text-center">
                <div className="text-lg font-black text-white">{selectedCar.engine}</div>
                <div className="text-gray-500 text-xs font-bold">ENGINE</div>
              </div>
            </div>

            {/* Stat Bars */}
            <div className="space-y-3 mb-6">
              <StatBar label="Speed" value={selectedCar.maxSpeed} max={15} color="#3B82F6" />
              <StatBar label="Accel" value={selectedCar.acceleration} max={0.25} color="#22C55E" />
              <StatBar label="Drift" value={selectedCar.driftFactor} max={1} color="#F59E0B" />
              <StatBar label="Grip" value={selectedCar.grip} max={1} color="#EF4444" />
              <StatBar label="Weight" value={1.1 - selectedCar.weight} max={1} color="#A855F7" />
            </div>

            {/* Description */}
            <p className="text-gray-400 text-sm text-center italic mb-6">{selectedCar.description}</p>

            {/* Select Button */}
            <button
              onClick={() => onSelect(selectedCar)}
              className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-black text-lg rounded-xl transition-all hover:scale-[1.02] hover:shadow-xl hover:shadow-blue-600/20 active:scale-95"
            >
              🏁 DRIVE BMW {selectedCar.name}
            </button>
          </div>

          {/* Car Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 auto-rows-min">
            {filteredCars.map((c, i) => (
              <button
                key={c.id}
                onClick={() => setSelectedIndex(i)}
                onMouseEnter={() => setHoveredIndex(i)}
                onMouseLeave={() => setHoveredIndex(null)}
                className={`relative rounded-xl p-3 transition-all duration-200 ${
                  selectedIndex === i
                    ? 'bg-blue-600/20 border-2 border-blue-500 shadow-lg shadow-blue-500/10 scale-105'
                    : hoveredIndex === i
                    ? 'bg-gray-800/60 border-2 border-white/20 scale-[1.02]'
                    : 'bg-gray-800/30 border-2 border-transparent hover:border-white/10'
                }`}
              >
                {selectedIndex === i && (
                  <div className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                    <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                )}

                <div className="flex justify-center mb-2">
                  {drawCarPreview(c, 80)}
                </div>
                <div className="text-center">
                  <div className="text-white text-sm font-bold">{c.name}</div>
                  <div className="text-gray-500 text-[10px]">{c.hp} HP · {c.year}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CarSelect;

import React, { useState, useCallback } from 'react';
import { CarSpec, GameScreen } from './game/types';
import MainMenu from './components/MainMenu';
import CarSelect from './components/CarSelect';
import Game from './components/Game';

const App: React.FC = () => {
  const [screen, setScreen] = useState<GameScreen>('menu');
  const [selectedCar, setSelectedCar] = useState<CarSpec | null>(null);

  const handlePlay = useCallback(() => {
    setScreen('select');
  }, []);

  const handleCarSelect = useCallback((car: CarSpec) => {
    setSelectedCar(car);
    setScreen('game');
  }, []);

  const handleBack = useCallback(() => {
    if (screen === 'game') {
      setScreen('select');
    } else {
      setScreen('menu');
    }
  }, [screen]);

  return (
    <div className="w-full h-screen overflow-hidden bg-black">
      {screen === 'menu' && (
        <MainMenu onPlay={handlePlay} />
      )}
      {screen === 'select' && (
        <CarSelect onSelect={handleCarSelect} onBack={handleBack} />
      )}
      {screen === 'game' && selectedCar && (
        <Game car={selectedCar} onBack={handleBack} />
      )}
    </div>
  );
};

export default App;
